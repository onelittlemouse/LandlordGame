#include"Game.h"

int main()
{
	Game g;
	g.play();
	return 0;
}